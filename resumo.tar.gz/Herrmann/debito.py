# -*- coding: UTF-8 -*-
# POC POS - Criação de entrada de débito para análise de contestações

import sys
from datetime import datetime
from pyspark import SparkConf, SparkContext
from pyspark.sql import Window, HiveContext
from pyspark.sql.functions import length, col, rowNumber, regexp_extract, concat, format_string, when

if len(sys.argv) < 2:
    print('Arguments: debito.py <output file>')
    print('Example: spark-submit --master yarn --queue cientistas --executor-memory 4G debito.py hdfs:/user/x181471/input_debito')
    sys.exit(1)

output_file = sys.argv[1]

conf = SparkConf().setAppName('POC POS Debito')
sc = SparkContext(conf=conf)
sqlContext = HiveContext(sc)

def latest(df, ids, timestamp_cols):
    return df \
        .withColumn('_row', rowNumber().over(
            Window \
                .partitionBy(*[col(id) for id in ids]) \
                .orderBy(*[col(timestamp_col).desc() for timestamp_col in timestamp_cols]))) \
        .filter(col('_row') == 1) \
        .drop('_row')

def latest_contcur(df, ids):
    return latest(df, ids, ['contcur'])

def latest_dat_ref_carga(df, ids):
    return latest(df, ids, ['dat_ref_carga'])

# Contestações

base_contestacao_df = sqlContext.table('arq_fraude.base_contestacao')

base_contestacao_latest_df = latest_dat_ref_carga(
    base_contestacao_df \
        .withColumn('numconta', base_contestacao_df.numconta.cast('long').cast('string')),
    ['codent', 'numagencia', 'numconta', 'dttransacao', 'valorfraude'])

compras_contestadas_pred = \
    (base_contestacao_latest_df.canal == 'AUTO ATENDIMENTO') & \
    (base_contestacao_latest_df.descricaotransacao == 'Compras')

compras_contestadas_df = base_contestacao_latest_df \
    .filter(compras_contestadas_pred) \
    .select(
        base_contestacao_latest_df.codent,
        base_contestacao_latest_df.numagencia,
        base_contestacao_latest_df.numconta,
        concat(
            base_contestacao_latest_df.codent,
            base_contestacao_latest_df.numagencia,
            format_string('%012d', base_contestacao_latest_df.numconta.cast('long'))) \
            .alias('ctacargo'),
        base_contestacao_latest_df.cartao,
        base_contestacao_latest_df.dttransacao,
        base_contestacao_latest_df.valorfraude)

# Vínculo com Contas

mpdt014_df = sqlContext.table('mp.mpdt014')

dat_ref_carga = mpdt014_df.groupBy().agg({'dat_ref_carga': 'max'}).collect()[0][0]
ultima_carga_pred = mpdt014_df.dat_ref_carga == dat_ref_carga

mpdt014_latest_df = latest_contcur(
    mpdt014_df.filter(ultima_carga_pred & (mpdt014_df.indcta == 'P')),
    ['codent', 'centalta', 'cuenta', 'ctacargo'])

contas_contratos_df = mpdt014_latest_df \
    .select(
        mpdt014_latest_df.codent,
        mpdt014_latest_df.centalta,
        mpdt014_latest_df.cuenta,
        mpdt014_latest_df.ctacargo,
        mpdt014_latest_df.fecalta,
        mpdt014_latest_df.fecbaja)

compras_contestadas_contratos_df = compras_contestadas_df \
    .withColumnRenamed('ctacargo', 'ctacargo_gen') \
    .join(
        contas_contratos_df \
            .withColumnRenamed('codent', 'codent_014'),
        (col('ctacargo_gen') == contas_contratos_df.ctacargo) &
        (compras_contestadas_df.dttransacao >= contas_contratos_df.fecalta) &
        (contas_contratos_df.fecbaja.isNull() | (compras_contestadas_df.dttransacao <= contas_contratos_df.fecbaja)),
        'left_outer')

# Extrato

mpdt090_df = sqlContext.table('mp.mpdt090')

data_attr = 'fecfac'
valor_attr = 'impdiv'
mpdt090_attrs = ['codent', 'centalta', 'cuenta', 'siaidcd', 'fecfac', 'impdiv', 'pan', 'impfac', 'impliq', 'codcom', 'nomcomred', 'codpais', 'nompob', 'fecconta']

mpdt090_latest_df = latest_contcur(
    mpdt090_df.filter(
        mpdt090_df.codcom.isNotNull() & (mpdt090_df.codcom != '')),
    ['codent', 'centalta', 'cuenta', 'siaidcd', data_attr, valor_attr]) \
    .select(*mpdt090_attrs) \
    .withColumnRenamed('codcom', 'codcom_090') \
    .withColumnRenamed('nomcomred', 'nomcomred_090') \
    .withColumnRenamed('impdiv', 'impdiv_090') \
    .withColumnRenamed('pan', 'pan_090') \
    .withColumnRenamed('fecconta', 'fecconta_090') \
    .withColumnRenamed('codpais', 'codpais_090') \

# Autorizações

mpdt004_df = sqlContext.table('mp.mpdt004')

mpdt004_latest_df = latest_contcur(mpdt004_df, ['codent', 'centalta', 'cuenta', 'siaidcd'])

mpdt004_df_attrs = ['codent', 'centalta', 'cuenta', 'siaidcd', 'pan', 'imptrn', 'impdiv', 'fectrn', 'hortrn', 'idterm', 'codact', 'codpais', 'codcom', 'nomcom', 'localidad', 'fecconta']

autorizacoes_debito_df = mpdt004_latest_df \
    .filter(
        (mpdt004_latest_df.inddebcre == '2') &
        mpdt004_latest_df.codcom.isNotNull() &
        (mpdt004_latest_df.codcom != '')) \
    .select(*mpdt004_df_attrs) \
    .withColumnRenamed('codcom', 'codcom_004') \
    .withColumnRenamed('nomcom', 'nomcom_004') \
    .withColumnRenamed('impdiv', 'impdiv_004') \
    .withColumnRenamed('pan', 'pan_004') \
    .withColumnRenamed('fecconta', 'fecconta_004') \
    .withColumnRenamed('codpais', 'codpais_004') \

debito_autorizado_df = mpdt090_latest_df.join(
    autorizacoes_debito_df,
    (mpdt090_latest_df.codent == autorizacoes_debito_df.codent) &
    (mpdt090_latest_df.centalta == autorizacoes_debito_df.centalta) &
    (mpdt090_latest_df.cuenta == autorizacoes_debito_df.cuenta) &
    (mpdt090_latest_df.siaidcd == autorizacoes_debito_df.siaidcd),
    'inner') \
    .drop(autorizacoes_debito_df.codent) \
    .drop(autorizacoes_debito_df.centalta) \
    .drop(autorizacoes_debito_df.cuenta) \
    .drop(autorizacoes_debito_df.siaidcd)

debito_df = debito_autorizado_df \
    .join(
        compras_contestadas_contratos_df,
        (compras_contestadas_contratos_df.codent == debito_autorizado_df.codent) &
        (compras_contestadas_contratos_df.centalta == debito_autorizado_df.centalta) &
        (compras_contestadas_contratos_df.cuenta == debito_autorizado_df.cuenta) &
        (compras_contestadas_contratos_df.valorfraude == debito_autorizado_df.impdiv_090) &
        (compras_contestadas_contratos_df.dttransacao == debito_autorizado_df.fecfac),
        'left_outer') \
    .drop(debito_autorizado_df.codent) \
    .drop(debito_autorizado_df.centalta) \
    .drop(debito_autorizado_df.cuenta)

# Modo de Entrada

mpdt343_df = sqlContext.table('mp.mpdt343')

mpdt343_latest_df = latest(mpdt343_df, ['cd_idef_sia'], ['dat_ref_carga', 'dh_ulti_atlz'])

attrs_343 = ['cd_idef_sia', 'in_senh', 'in_codi_segr', 'in_crto_chip', 'nr_crto', 'dh_tran', 'vl_orig_tran', 'cd_empr_grup_sntd', 'nr_cntr_crto', 'cd_idef_tran', 'cd_entr_pos']
input_debito_df = debito_df \
    .withColumn('contestada', debito_df.ctacargo_gen.isNotNull()) \
    .join(
        mpdt343_latest_df \
            .select(*[col(attr) for attr in attrs_343]) \
            .withColumn('in_senh', mpdt343_latest_df.in_senh == '1') \
            .withColumn('in_codi_segr', mpdt343_latest_df.in_codi_segr == '1') \
            .withColumn('in_crto_chip', when(mpdt343_latest_df.in_crto_chip == 'S', True) \
                                       .when(mpdt343_latest_df.in_crto_chip == 'N', False) \
                                       .otherwise(None)),
        debito_df.siaidcd == mpdt343_latest_df.cd_idef_sia,
        'left_outer')

# Saída

input_debito_df \
    .select(*[col(attr) for attr in ['siaidcd', 'pan_004', 'fectrn', 'hortrn', 'imptrn', 'codcom_004', 'nomcom_004', 'codact', 'idterm', 'cd_entr_pos', 'codpais_004', 'contestada']]) \
    .distinct() \
    .write.mode('overwrite').parquet(output_file)

sys.exit(0)
