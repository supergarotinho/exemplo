# -*- coding: UTF-8 -*-
# POC POS - Análise de contestações de compras no débito a partir de dados brutos

import sys
from datetime import datetime
from pyspark import SparkConf, SparkContext
from pyspark.sql import Window, HiveContext
from pyspark.sql.functions import length, col, rowNumber, regexp_extract, concat, format_string, when, datediff, count, sum, to_date, first

if len(sys.argv) < 2:
    print('Arguments: debito.py <output file>')
    print('Example: spark-submit --master yarn --queue cientistas --executor-memory 4G debito_analise.py hdfs:/user/x181471/input_debito_result')
    sys.exit(1)

output_file = sys.argv[1]

conf = SparkConf().setAppName('POC POS Debito Analise')
sc = SparkContext(conf=conf)
sqlContext = HiveContext(sc)

def latest(df, ids, timestamp_cols):
    return df \
        .withColumn('_row', rowNumber().over(
            Window \
                .partitionBy(*[col(id) for id in ids]) \
                .orderBy(*[col(timestamp_col).desc() for timestamp_col in timestamp_cols]))) \
        .filter(col('_row') == 1) \
        .drop('_row')

def latest_contcur(df, ids):
    return latest(df, ids, ['contcur'])

def latest_dat_ref_carga(df, ids):
    return latest(df, ids, ['dat_ref_carga'])

# Contestações

base_contestacao_df = sqlContext.table('arq_fraude.base_contestacao')

base_contestacao_latest_df = latest_dat_ref_carga(
    base_contestacao_df \
        .withColumn('numconta', base_contestacao_df.numconta.cast('long').cast('string')),
    ['codent', 'numagencia', 'numconta', 'dttransacao', 'valorfraude'])

compras_contestadas_pred = \
    (base_contestacao_latest_df.canal == 'AUTO ATENDIMENTO') & \
    (base_contestacao_latest_df.descricaotransacao == 'Compras')

compras_contestadas_df = base_contestacao_latest_df \
    .filter(compras_contestadas_pred) \
    .select(
        base_contestacao_latest_df.codent,
        base_contestacao_latest_df.numagencia,
        base_contestacao_latest_df.numconta,
        concat(
            base_contestacao_latest_df.codent,
            base_contestacao_latest_df.numagencia,
            format_string('%012d', base_contestacao_latest_df.numconta.cast('long'))) \
            .alias('ctacargo'),
        base_contestacao_latest_df.dttransacao,
        base_contestacao_latest_df.valorfraude)

# Vínculo com Contas

mpdt014_df = sqlContext.table('mp.mpdt014')

dat_ref_carga = mpdt014_df.groupBy().agg({'dat_ref_carga': 'max'}).collect()[0][0]
ultima_carga_pred = mpdt014_df.dat_ref_carga == dat_ref_carga

mpdt014_latest_df = latest_contcur(
    mpdt014_df.filter(ultima_carga_pred & (mpdt014_df.indcta == 'P')),
    ['codent', 'centalta', 'cuenta', 'ctacargo'])

contas_contratos_df = mpdt014_latest_df \
    .select(
        mpdt014_latest_df.codent,
        mpdt014_latest_df.centalta,
        mpdt014_latest_df.cuenta,
        mpdt014_latest_df.ctacargo,
        mpdt014_latest_df.fecalta,
        mpdt014_latest_df.fecbaja)

compras_contestadas_contratos_df = compras_contestadas_df \
    .withColumnRenamed('ctacargo', 'ctacargo_gen') \
    .join(
        contas_contratos_df \
            .withColumnRenamed('codent', 'codent_014'),
        (col('ctacargo_gen') == contas_contratos_df.ctacargo) &
        (compras_contestadas_df.dttransacao >= contas_contratos_df.fecalta) &
        (contas_contratos_df.fecbaja.isNull() | (compras_contestadas_df.dttransacao <= contas_contratos_df.fecbaja)),
        'left_outer')

# Extrato

mpdt090_df = sqlContext.table('mp.mpdt090')

data_attr = 'fecfac'
valor_attr = 'impdiv'
mpdt090_attrs = ['codent', 'centalta', 'cuenta', 'siaidcd', 'fecfac', 'impdiv', 'pan', 'impfac', 'impliq', 'codcom', 'nomcomred', 'codpais', 'nompob', 'fecconta']

mpdt090_latest_df = latest_contcur(
    mpdt090_df.filter(
        mpdt090_df.codcom.isNotNull() & (mpdt090_df.codcom != '')),
    ['codent', 'centalta', 'cuenta', 'siaidcd', data_attr, valor_attr]) \
    .select(*mpdt090_attrs) \
    .withColumnRenamed('codcom', 'codcom_090') \
    .withColumnRenamed('nomcomred', 'nomcomred_090') \
    .withColumnRenamed('impdiv', 'impdiv_090') \
    .withColumnRenamed('pan', 'pan_090') \
    .withColumnRenamed('fecconta', 'fecconta_090') \
    .withColumnRenamed('codpais', 'codpais_090') \

# Autorizações

mpdt004_df = sqlContext.table('mp.mpdt004')

mpdt004_latest_df = latest_contcur(mpdt004_df, ['codent', 'centalta', 'cuenta', 'siaidcd'])

mpdt004_df_attrs = ['codent', 'centalta', 'cuenta', 'siaidcd', 'pan', 'imptrn', 'impdiv', 'fectrn', 'hortrn', 'idterm', 'codact', 'codpais', 'codcom', 'nomcom', 'localidad', 'fecconta']

autorizacoes_debito_df = mpdt004_latest_df \
    .filter(
        (mpdt004_latest_df.inddebcre == '2') &
        mpdt004_latest_df.codcom.isNotNull() &
        (mpdt004_latest_df.codcom != '')) \
    .select(*mpdt004_df_attrs) \
    .withColumnRenamed('codcom', 'codcom_004') \
    .withColumnRenamed('nomcom', 'nomcom_004') \
    .withColumnRenamed('impdiv', 'impdiv_004') \
    .withColumnRenamed('pan', 'pan_004') \
    .withColumnRenamed('fecconta', 'fecconta_004') \
    .withColumnRenamed('codpais', 'codpais_004') \

debito_autorizado_df = mpdt090_latest_df.join(
    autorizacoes_debito_df,
    (mpdt090_latest_df.codent == autorizacoes_debito_df.codent) &
    (mpdt090_latest_df.centalta == autorizacoes_debito_df.centalta) &
    (mpdt090_latest_df.cuenta == autorizacoes_debito_df.cuenta) &
    (mpdt090_latest_df.siaidcd == autorizacoes_debito_df.siaidcd),
    'inner') \
    .drop(autorizacoes_debito_df.codent) \
    .drop(autorizacoes_debito_df.centalta) \
    .drop(autorizacoes_debito_df.cuenta) \
    .drop(autorizacoes_debito_df.siaidcd)

debito_df = debito_autorizado_df \
    .join(
        compras_contestadas_contratos_df,
        (compras_contestadas_contratos_df.codent == debito_autorizado_df.codent) &
        (compras_contestadas_contratos_df.centalta == debito_autorizado_df.centalta) &
        (compras_contestadas_contratos_df.cuenta == debito_autorizado_df.cuenta) &
        (compras_contestadas_contratos_df.valorfraude == debito_autorizado_df.impdiv_090) &
        (compras_contestadas_contratos_df.dttransacao == debito_autorizado_df.fecfac),
        'left_outer') \
    .drop(debito_autorizado_df.codent) \
    .drop(debito_autorizado_df.centalta) \
    .drop(debito_autorizado_df.cuenta)

# Modo de Entrada

mpdt343_df = sqlContext.table('mp.mpdt343')

mpdt343_latest_df = latest(mpdt343_df, ['cd_idef_sia'], ['dat_ref_carga', 'dh_ulti_atlz'])

attrs_343 = ['cd_idef_sia', 'in_senh', 'in_codi_segr', 'in_crto_chip', 'nr_crto', 'dh_tran', 'vl_orig_tran', 'cd_empr_grup_sntd', 'nr_cntr_crto', 'cd_idef_tran', 'cd_entr_pos']
input_debito_df = debito_df \
    .withColumn('contestada', debito_df.ctacargo_gen.isNotNull()) \
    .join(
        mpdt343_latest_df \
            .select(*[col(attr) for attr in attrs_343]) \
            .withColumn('in_senh', mpdt343_latest_df.in_senh == '1') \
            .withColumn('in_codi_segr', mpdt343_latest_df.in_codi_segr == '1') \
            .withColumn('in_crto_chip', when(mpdt343_latest_df.in_crto_chip == 'S', True) \
                                       .when(mpdt343_latest_df.in_crto_chip == 'N', False) \
                                       .otherwise(None)),
        debito_df.siaidcd == mpdt343_latest_df.cd_idef_sia,
        'left_outer')

# Dataset

input_debito_df \
    .select(*[col(attr) for attr in ['siaidcd', 'pan_004', 'fectrn', 'hortrn', 'imptrn', 'codcom_004', 'nomcom_004', 'codact', 'idterm', 'cd_entr_pos', 'codpais_004', 'contestada']]) \
    .distinct()

# Análise

transactions_df = input_debito_df \
    .withColumnRenamed('pan_004', 'cartao') \
    .withColumnRenamed('codcom_004', 'idEstabelecimento') \
    .withColumnRenamed('fectrn', 'dataHoraAutorizacao') \
    .withColumnRenamed('siaidcd', 'idSia') \
    .withColumnRenamed('contestada', 'flagContestacao') \
    .withColumn('valor', col('imptrn').cast('float')).drop(col('imptrn')) \
    .select(col('cartao'), col('idEstabelecimento'), col('dataHoraAutorizacao'), col('idSia'), col('flagContestacao'), col('valor'))

# Passo 1: Extrair transações contestadas
contestacoes_df = transactions_df \
    .filter(transactions_df.flagContestacao == True) \
    .withColumnRenamed('dataHoraAutorizacao', 'dataHoraAutorizacaoContest') \
    .withColumnRenamed('valor', 'valorContest') \
    .withColumnRenamed('idSia', 'idSiaContest') \
    .drop(transactions_df.flagContestacao) \
    .cache()

# Passo 2: Transações com contestação futura
seqs_df = transactions_df \
    .join(contestacoes_df, 'cartao') \
    .filter(datediff(
        contestacoes_df.dataHoraAutorizacaoContest,
        transactions_df.dataHoraAutorizacao) > 0)

# Passo 3: Agregação de contestações futuras
contest_fut_df = seqs_df \
    .groupBy(transactions_df.idSia) \
    .agg(
        count('*').alias('contestFuturas'),
        sum('valorContest').alias('valorTotalContestFuturas')) \
    .alias('contest_fut')

# Passo 4: Marcar número de contestações futuras para cada transação
enriched_transactions_df = transactions_df.withColumnRenamed('idSia', 'idSiaTran') \
    .join(
        contest_fut_df,
        col('idSiaTran') == contest_fut_df.idSia,
        'left_outer') \
    .drop(contest_fut_df.idSia) \
    .na.fill(0, 'contestFuturas') \
    .na.fill(0, 'valorTotalContestFuturas') \
    .withColumnRenamed('idSiaTran', 'idSia')

# Passo 5: Agrupar buckets e cartões com estatísticas de contestações futuras
enriched_transactions_hist_df = enriched_transactions_df \
    .groupBy(
        transactions_df.idEstabelecimento,
        to_date(transactions_df.dataHoraAutorizacao).alias('date'),
        transactions_df.cartao) \
    .agg(
        count('*').alias('count'),
        first(enriched_transactions_df.contestFuturas) \
            .alias('contestFuturas'),
        first(enriched_transactions_df.valorTotalContestFuturas) \
            .alias('valorTotalContestFuturas'))

# Passo 6: Agregar estatísticas dos buckets
bucket_stats_df = enriched_transactions_hist_df \
    .groupBy(
        enriched_transactions_hist_df.idEstabelecimento,
        enriched_transactions_hist_df.date) \
    .agg(
        count('*').alias('cartoes'),
        sum('count').alias('transacoes'),
        sum(enriched_transactions_hist_df.contestFuturas) \
            .alias('transacoesContestFuturas'),
        sum(when(enriched_transactions_hist_df.contestFuturas > 0, 1) \
                .otherwise(0)) \
            .alias('cartoesContestFuturas'),
        sum(enriched_transactions_hist_df.valorTotalContestFuturas) \
            .alias('valorTotalContestFuturas'))

# Passo 7: Contagem de cartões distintos com contestações nos buckets
transactions_hist_df = contestacoes_df \
    .groupBy(
        contestacoes_df.idEstabelecimento,
        to_date(contestacoes_df.dataHoraAutorizacaoContest).alias('date'),
        contestacoes_df.cartao) \
    .agg(
        count('*').alias('count'),
        sum('valorContest').alias('valorContest'))

# Passo 8: Agregação de estatísticas presentes dos buckets
contest_bucket_stats_df = transactions_hist_df \
    .groupBy(
        transactions_hist_df.idEstabelecimento,
        transactions_hist_df.date) \
    .agg(
        count('*').alias('cartoesContest'),
        sum('count').alias('transacoesContest'),
        sum('valorContest').alias('valorTotalContest')) \
    .withColumnRenamed('idEstabelecimento', 'idEstabelecimentoContest') \
    .withColumnRenamed('date', 'dateContest')

# Passo 9: Junção de estatísticas futuras e presentes
stats_df = bucket_stats_df \
    .join(
        contest_bucket_stats_df,
        (bucket_stats_df.idEstabelecimento == contest_bucket_stats_df.idEstabelecimentoContest) &
        (bucket_stats_df.date == contest_bucket_stats_df.dateContest),
        'left_outer') \
    .drop('idEstabelecimentoContest').drop('dateContest') \
    .na.fill(0, 'cartoesContest') \
    .na.fill(0, 'transacoesContest') \
    .na.fill(0, 'valorTotalContest') \
    .filter(col('transacoesContestFuturas') > 0)

# Passo 10: Cálculo de taxas futuras/presente
results_df = stats_df \
    .withColumn('taxaCartoesContestFuturas', stats_df.cartoesContestFuturas / stats_df.cartoes) \
    .withColumn('taxaTransacoesContestFuturas', stats_df.transacoesContestFuturas / stats_df.transacoes) \
    .orderBy(col('taxaCartoesContestFuturas').desc(), stats_df.valorTotalContestFuturas.desc())

# Saída
results_df.write.mode('overwrite').parquet(output_file)